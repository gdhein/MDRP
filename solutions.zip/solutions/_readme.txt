The original instances available in TSPLIB have their vertices numbered, and the depot is numbered as 1.
The solutions presented use the same notation, so the depot is also presented as number 1.